#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    FILE *arq;
    char c;

    if(argc < 2)
    {
        fprintf(stderr, "Parametros invalidos!");
        exit(1);
    }
    arq = fopen(argv[1], "r+t");

    if(arq == NULL)
    {
        fprintf(stderr, "Falha ao abrir o arquivo");
        exit(1);
    }

    while(1)
    {
        c = fgetc(arq);
        if (c == EOF)
            break;
        printf("%c", c);
    }
    fclose(arq);
    return 0;
}
