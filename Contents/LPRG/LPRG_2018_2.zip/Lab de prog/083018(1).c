#include <stdio.h>
#include <stdlib.h>

int main()
{
    int entrada, cont, i;
    int *numeros = NULL;
    int *novo = NULL;
    cont =0;
    do
    {
        printf("Informe um numero:");
        scanf("%d", &entrada);
        cont++;

        novo = realloc(numeros, cont * sizeof(int));

        if (novo == NULL)
        {
            printf("Erro, abortando...");// caso n�o conseiga alocar memoria

            free(numeros);
            exit(1);
        }
        numeros = novo;
        numeros[cont-1] = entrada;
    }
    while(entrada!=0);
    printf("Numeros informados>:\n");
    for (i=0; i<cont; i++)
    printf("%d\t",  numeros[i]);//'\t' = "Tab"
    free(numeros);
    free(novo);

    return 0;
}
