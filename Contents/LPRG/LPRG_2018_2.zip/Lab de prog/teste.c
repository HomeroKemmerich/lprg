#include <stdio.h>

int main ()
{
    int j,soma=0;
    for (j=0; j<2; j++)
    {
        soma = soma + 2^j;
    }
    printf("%d", soma);
}
