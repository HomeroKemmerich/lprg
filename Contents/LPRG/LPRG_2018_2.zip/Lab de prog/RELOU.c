#include <stdio.h>

int main (void){
int n1, n2;
printf("Digite dois valores:\n");
scanf ("%d", &n1);
scanf ("%d", &n2);
printf ("Valor 1: %d \n", n1);
printf ("Valor 2: %d \n", n2);
return 0;
}
