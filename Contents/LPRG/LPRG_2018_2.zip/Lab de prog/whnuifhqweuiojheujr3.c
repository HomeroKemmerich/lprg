#include <stdio.h>

int main ()
{
    int N, X, i, j;
    unsigned long long int soma = 0;

    scanf ("%d", &N); //L� N

    unsigned long long int V[N];

    for (i=0; i<N; i++) // L� X N vezes
    {
        scanf("%d", &X);

        if ((X>0)&&(X<65))
        {
            for (j=0; j<X; j++)
            {
                soma = soma + pow (2, j);
            }
            V[i] = (soma/12)/1000;
            printf("%d", V[i]);
        }
    }
}
