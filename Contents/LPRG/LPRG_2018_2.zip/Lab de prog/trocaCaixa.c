#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

///substitui as v�rgulas por '\t' e ponto e virgula por '\n'

int main(int argc, char **argv)
{

    FILE *src, *dest;
    char c;

    if(argc!=3)
    {
        fprintf(stderr, "Parametros Invalidos\n <nome_prog> <arq_entrada> <arq_saida>");
        exit(1);
    }

    src = fopen(argv[1], "r+t");
    if(src==NULL)
    {
        fprintf(stderr, "Erro ao abrir o arquivo de origem");
        exit(1);
    }

    dest = fopen(argv[2], "w+t");
    if(dest==NULL)
    {
        fprintf(stderr, "Erro ao abrir o arquivo de destino");
        exit(1);
    }

    do
    {
        c = fgetc(src);
        if(c == EOF)
            break;
        if (c == ';') fputc('\n', dest);
        else if (c == ',') fputc('\t', dest);
        else fputc(c, dest);
    }
    while(1);

    fclose(src);
    fclose(dest);
    return (0);
}
