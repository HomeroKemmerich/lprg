#include <stdio.h>
#include <string.h>

int main()
{
    char famoso[4]="lula";
    char resposta[50];
    char *dicas[5]=
    {
        "� homem",
        "Ou voc� gosta ou voc� odeia"
        "� da pol�tica"
        "� canditato � presid�ncia"
        "T� preso"

    }
    int tent = 0;
    char chose;
    printf("Adivinhe o famoso que eu estou pensando\n");
    do
    {
        fflush(stdin);
        gets(resposta);
        {
            if (strcmp(famoso, resposta)==0)
            {
                printf("Nossa, voce acertou");
            }
            else
            {
                tent++;
                printf("errou, vai de novo\n");

            }
            if (tent%5==0)
            {
                printf("\nDeseja continuar? \nS - Sim \nN - Nao\n");
                gets(chose);
                }
            }

        }
    while (1);
}
