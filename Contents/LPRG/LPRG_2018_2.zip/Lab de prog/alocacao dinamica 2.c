#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *vet, n, i;

    printf("Informe a quantidade de elementos:");
    scanf("%d", &n);

    vet  = malloc(n*sizeof(int));//define o tamanho do vetor (n vezes o tipo de mem�ria) no endere�o indicado
    if (vet==NULL)
    {
        printf("n�o foi poss�vel alocar mem�ria, encerrando...");
        return (1);
    }

    for(i=0; i<n; i++)
    {
        printf("[%d]: ", i);
        scanf("%d\n", &vet[i]);
    }

    for (i=0; i<n;i++)
    {
        printf("%d\n", vet[i]);
    }
    free(vet); //libera a mem�ria

    return 0;
}
