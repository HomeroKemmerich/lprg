#include <stdio.h>

struct Data
{
    int dia, mes, ano;
};

typedef struct
{
    char nome[100];
    struct Data dt_n;
    int idade;
} Pessoa;

int ehValida(struct Data d);
int calcIdade(Data d);

int main()
{
    struct Data d= {16,8,2018};
    struct Data d2= {05,8,2016};

    Pessoa p;

    printf("%d/%d/%d", d.dia, d.mes, d.ano);

    return 0;
}
