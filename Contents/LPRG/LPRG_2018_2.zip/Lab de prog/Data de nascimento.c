#include <stdio.h>

typedef struct
{
    int dia, mes, ano;
}Data;

typedef struct
{
    char nome[100];
    Data dt_n;
    int idade;
}Pessoa;

int ehValida(Data d)
{
    int F;
    F=d.ano*2;
    return F;
}
int calcIdade(Data d)
{
};

int main(){
    Data hoje = {16,8,2018};
    Pessoa p;

    printf("Quem eh voce?\n");
    gets(p.nome);

    printf("\nQuando voce nasceu?(dd mm aaaa)\n");
    scanf("%d %d %d",&p.dt_n.dia, &p.dt_n.mes, &p.dt_n.ano);
    calcIdade(p.dt_n);

return 0;
}
