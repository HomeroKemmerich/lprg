//FUAQ auxilia uma secret�ria na rotina de calculo de m�dia dos alunos.
//A turma ter� no maximo 20 alunos. Cada aluno possui 3 notas, 1 numero de  matricula e seu respectivo nome.
//Sua tarefa � ler inicialmente a qua\ntidade de alunos na turma. Ap�s, a leitura dos dados (matricula, nome, notas)
//Calcular a m�dia de cada aluno.
// Ao final da leitura exiba um menu com as seguintes op��es:
//1- mostrar todas as notas/m�dia
//2- procurar um aluno pela matr�cula
#include <stdio.h>

typedef struct
{
    int Ma;
    char NO[35];
    float n1, n2, n3, med;
} Dado;

int main()
{
    int Qtd, i, opc, Ma1;;
    printf("Quantos alunos tem a sua turma?(0-20)\n");
    scanf("%d", &Qtd);
    if ((Qtd<=20)&&(Qtd>0))
    {
        Dado MA[Qtd];
        printf("\nInsira os dados:\n");
        for (i=0; i<Qtd; i++)
        {
            printf("\nAluno %d", i+1);
            printf("\nMatricula: ");
            scanf("%d", &MA[i].Ma);

            printf("\nNome: ");
            scanf("%s", &MA[i].NO);

            printf("\nNota 1: ");
            scanf("%f", &MA[i].n1);

            printf("\nNota 2: ");
            scanf("%f", &MA[i].n2);

            printf("\nNota 3: ");
            scanf("%f", &MA[i].n3);

            MA[i].med = (MA[i].n1 + MA[i].n2 + MA[i].n3)/3;
        }
        do
        {
            menu();
            scanf("%d", &opc);

            switch(opc)
            {
            case(2):
                scanf("%d", &Ma1);
                for(i=0; i<=Qtd; i++)
                {
                    if(MA[i].Ma == Ma1)
                    {
                        printf("%d %s %.1f %.1f %.1f %.1f", MA[i].Ma, MA[i].NO, MA[i].n1, MA[i].n2, MA[i].n3, MA[i].med);
                    }
                }
                break;
            case (1):
                for(i=0; i<=Qtd; i++)
                {
                    printf("%d %s %.1f %.1f %.1f %.1f", MA[i].Ma, MA[i].NO, MA[i].n1, MA[i].n2, MA[i].n3, MA[i].med);
                }
                break;
            case (0):
                break;

            }
        }
        while(opc!=0);
    }
    else
    {
        printf("Valor inv�lido, tente novamente\n");
        return 1;
    }
}

void menu()
{
    printf("\n%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",201,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,187);
    printf("%c    MENU PRINCIPAL     %c\n",186,186);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",204,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,185);
    printf("%c  1 - Mostar todos     %c\n",186,186);
    printf("%c  2 - Consultar        %c\n",186,186);
    printf("%c                       %c\n",186,186);
    printf("%c  0 - Finalizar        %c\n",186,186);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",200,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,188);

}
