#include <stdio.h>
#include<stdlib.h>

typedef struct
{
    char NOME[30];
    int idade;
    float altura;
} Pessoa;
int main()
{
    int entrada, cont = 0, i, escolhido;
    Pessoa *pessoas = NULL;
    Pessoa *novo = NULL;

    do
    {
        printf("\n%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",201,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,187);
        printf("%c    MENU PRINCIPAL     %c\n",186,186);
        printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",204,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,185);
        printf("%c  1 - Incluir pessoa   %c\n",186,186);
        printf("%c  2 - Mostrar lista    %c\n",186,186);
        printf("%c                       %c\n",186,186);
        printf("%c  0 - Finalizar        %c\n",186,186);
        printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",200,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,188);

        scanf("%c", escolhido);
        switch (escolhido)
        {
        case '1':
            novo = realloc(pessoas, cont*sizeof(Pessoa));

            fflush(stdin);

            printf("\nNome: ");
            gets(novo.NOME);

            printf("\nIdade: ");
            scanf("%d", &novo.idade);

            printf("\nAltura")
            scanf("%f", &novo.altura);

            if (novo == NULL)
            {
                printf("ERRO");
                free(pessoas);
                return (1);
            }

        }
    }
    while (escolhido != 0);
    return 0;
}


