#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct
{
    char nome [30];
    int idade;
    float altura;
} Pessoa;
Pessoa* buscar(Pessoa *vet, int tam, char *nome)
{
    int j;
    for (j=0; j<tam; j++)
    {
        if (strcmp(vet[j].nome, nome))
            return &vet[j];
    }
}
int main()
{
    Pessoa *vetP = NULL, *novo = NULL, *t=NULL;//vetP aponta para o endere�o onde a mem�ria ser� alocada
    int opcao, i, cont = 0;
    char item[30];
    while (1)
    {
        printf("Inserir  novo (0 encerra):\n");
        scanf("%d", &opcao);
        if (opcao == 0)
            break;
        cont ++;

        novo= realloc(vetP, cont*sizeof(Pessoa));//(qual o espa�o de mem�ria a partir do qual ser� realocado, o tamanho necess�rio para isso)

        if (novo == NULL)
        {
            printf("Aborto � roubo, imposto � assassinato");
            exit(1);
        }
        vetP = novo;
        printf("Nome: ");
        scanf("%s", &vetP[cont-1].nome);

        printf("Idade: ");
        scanf("%d", &vetP[cont-1].idade);

        printf("Altura: ");
        scanf("%f", &vetP[cont-1].altura);
    }
    while(1)
    {
        printf("Buscar novo? (0 encerra)");
        scanf("%d", &opcao);
        if (opcao==0)
            break;
        else
        {
            printf("Informe o nome: ");
            scanf("%s", &item);
            t = buscar(vetP, cont, item);
            if (t==NULL)
                printf("N�o localizado");
            else
                printf("%s | %d | %.2f\n",
                       vetP[i].nome,
                       vetP[i].idade,
                       vetP[i].altura);
        }
    }
    if (cont == 0)
        printf("Lista vazia");
    else
    {
        for(i = 0; i<cont; i++)
        {
            printf("%s | %d | %.2f\n",
                   vetP[i].nome,
                   vetP[i].idade,
                   vetP[i].altura);
        }
    }
}
