#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char nome[30];
    int idade;
    float altura;
} Pessoa;
int main()
{
    int x, Y[3], z=100;
    Pessoa p;
    int *vet, n;//ponteiro

    x = sizeof(z);//sizeof()retorna a quantidade de bytes de um elemento
    printf("z utiliza %d bytes\n", x);
    x  = sizeof(Y);
    printf("\nY utiliza %d bytes\n", x);
    printf("\nPessoa utiliza %d bytes\n", sizeof(p));
    return 0;
}
