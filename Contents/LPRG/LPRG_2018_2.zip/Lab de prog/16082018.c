#include <stdio.h>
#include <string.h>

int main()
{
    char cidade[50]="Passo Fundo";
    char estado[3]= {'R', 'S', '\0'}; //O \0 � memro de qualquer vetor automaticamente
    char escolha='S';
    int qtdChar;

    printf("Cidade %s/%s", cidade, estado);

    printf("\nInforme sua cidade: ");

    fflush(stdin); //fflush limpa o buffer da entrada principal (stdin -  teclado)
    gets(cidade); //scanf ("%s", &cidade) que aceita espa�oes em branco
    qtdChar = strlen(cidade);//strlen() "conta" a quantidade de caracteres
    printf("\nInforme seu estado: ");
    scanf("%s", &estado);

    printf("\nCidade: %s/%s", cidade, estado);
    printf("\nQuantidade de caracteres: %d", qtdChar);

    return 0;
}
