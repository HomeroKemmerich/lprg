#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char nome[30];
    int idade;
    float altura;
}Pessoa;
int main()
{
    int n,i;
    Pessoa *p;

    printf("Informe a quantidade de pessoas: ");
    scanf("%d", &n);

    p = malloc(n*sizeof(Pessoa));

    if (p == NULL)
    {
        printf("Nao foi possivel alocar memoria, encerrando...");
        return (1);
    }
    for(i=0; i<n; i++)
    {
        if (i>0)
            printf("\nProximo\n");

        fflush(stdin);

        printf("\nInsira o nome:");
        gets(p[i].nome);

        printf("\nAgora a idade:");
        scanf("%d", &p[i].idade);

        printf("\nE a altura:");
        scanf("%f", &p[i].altura);
    }
    for (i=0; i<n; i++)
    {
        printf("\n %s %d %.2f", p[i].nome, p[i].idade, p[i].altura);
    }
    return 0;
}
