#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
///fopen sempre retorna um ponteiro
///argv � ** pois � um array de array (igual a *argv[])
int main(int argc, char **argv)
{

    FILE *src, *dest;
    char c;

    if(argc!=3)
    {
        fprintf(stderr, "Parametros Invalidos\n <nome_prog> <arq_entrada> <arq_saida>");
        exit(1);
    }

    src = fopen(argv[1], "r");
    if(src==NULL)
    {
        fprintf(stderr, "Erro ao abrir o arquivo de origem\n");
        exit(1);
    }

    dest = fopen(argv[2], "w+t");
    if(dest==NULL)
    {
        fprintf(stderr, "Erro ao abrir o arquivo de destino\n");
        exit(1);
    }

    do
    {
        c = fgetc(src);
        if(c == EOF)
            break;
        if (isalpha(c))
        {
            if(islower(c))
                fputc(toupper(c), dest);
            else if(isupper(c))
                fputc(tolower(c), dest);
        }
        else
        {
            fputc(c, dest);
        }
    }
    while(1);

    fclose(src);
    fclose(dest);
    return (0);
}
