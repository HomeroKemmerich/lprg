#include <stdio.h>
#include <stdlib.h>

#define TAM 255
int main(int argc, char **argv)
{
    FILE *arq;
    char linha[TAM];

    if(argc != 2)
    {
        printf("Parametrod invalidos");
        exit(1);
    }


    arq = fopen(argv[1], "r");
    if (arq == NULL)
    {

        printf("nao conseguiu abrir o arquivo");
    }

    while(fgets(linha, sizeof(linha), arq)!=NULL)
    {
        fputs(linha, stdout); ///stdout = saida padrao do PC (monitor)
    }

}
