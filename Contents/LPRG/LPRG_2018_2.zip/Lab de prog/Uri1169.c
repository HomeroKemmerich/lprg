#include <stdio.h>

int main ()
{
    int  N, X, i, j;
    unsigned long long int soma;

    scanf("%d", &N);

    unsigned long long int V[N];

    for (i=0; i<N; i++)
    {
        scanf ("%d", &X);

        if ((X>0)&&(X<65))
        {
            for (j = 0; j<X; j++)
            {
                soma = soma + 2^j;
            }
            V[j] = (soma/12)/1000;
        }
    }
    for (i=0; i<N; i++)
        {
            printf ("%d \n", V[i]);
        }

    return 0;
}
